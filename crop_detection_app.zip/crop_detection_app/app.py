import streamlit as st
from tensorflow.keras.models import load_model
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import matplotlib.pyplot as plt

# Load model
model = load_model("crop_model.h5")

# Set this to match your class folders inside PlantVillage/
class_names = ['Pepper__bell___Bacterial_spot', 'Pepper__bell___healthy', 'Potato___Early_blight',
               'Potato___healthy', 'Potato___Late_blight', 'Tomato__Target_Spot',
               'Tomato__Tomato_mosaic_virus','Tomato__Tomato_YellowLeaf__Curl_Virus', 'Tomato_Bacterial_spot',
               'Tomato_Early_blight','Tomato_healthy','Tomato_Late_blight',
               'Tomato_Leaf_Mold','Tomato_Septoria_leaf_spot','Tomato_Spider_mites_Two_spotted_spider_mite'] 

# Disease details (add as needed)
disease_info = {
    'Potato___Early_blight': {
        'description': 'Fungal disease causing dark spots on leaves.',
        'treatment': 'Use fungicides like chlorothalonil or mancozeb.'
    },
    'Potato___healthy': {
        'description': 'Leaf appears green and normal with no signs of disease.',
        'treatment': 'No action needed. Keep monitoring regularly.'
    },
    'Tomato_Leaf_Mold': {
        'description': 'Fungal infection with yellow patches turning brown.',
        'treatment': 'Ensure airflow, avoid overhead watering, use fungicide.'
    },
    'Tomato_healthy': {
        'description': 'Leaf is disease-free and vibrant green.',
        'treatment': 'Keep up good watering and fertilization habits.'
    },
    'Pepper__bell___Bacterial_spot': {
        'description': 'Causes small, water-soaked spots that turn brown.',
        'treatment': 'Copper-based sprays and disease-free seeds help.'
    },
    # You can add all others as needed...
}

# Predict function
def predict_crop_from_leaf(pil_image):
    image = pil_image.resize((64, 64))
    img_array = np.array(image) / 255.0
    img_array = np.expand_dims(img_array, axis=0)
    predictions = model.predict(img_array)
    predicted_index = np.argmax(predictions[0])
    predicted_class = class_names[predicted_index]
    confidence = round(np.max(predictions[0]) * 100, 2)
    return predicted_class, confidence, predictions[0]

# Streamlit UI
st.set_page_config(page_title="Crop Leaf Detector", page_icon="🍃")
st.title("🍃 PlantVillage Crop Leaf Disease Detector")
st.write("Upload a leaf image to detect its crop and possible disease.")

uploaded_file = st.file_uploader("📤 Upload a leaf image", type=["jpg", "jpeg", "png"])

if uploaded_file is not None:
    image = Image.open(uploaded_file)
    st.image(image, caption="Uploaded Leaf Image", use_container_width=True)

    with st.spinner("Analyzing..."):
        predicted_class, confidence, all_probs = predict_crop_from_leaf(image)

    # Show prediction
    st.subheader(f"🧪 Detected: `{predicted_class}`")
    st.success(f"Confidence: **{confidence}%**")
    st.write("📊 Model output shape:", model.output_shape)

    # Show disease info
    if predicted_class in disease_info:
        st.markdown("### 📋 Disease Info")
        st.write(f"**Description:** {disease_info[predicted_class]['description']}")
        st.write(f"**Treatment / Advice:** {disease_info[predicted_class]['treatment']}")
    else:
        st.info("No detailed information available for this class.")

    st.write("🔢 Prediction vector length:", len(all_probs))
    st.write("📁 Number of class names:", len(class_names))
    st.write("📄 Class names:", class_names)
    # Plot confidence bar chart
    
    
    # Get top prediction
    predicted_index = np.argmax(all_probs)
    predicted_class = class_names[predicted_index]
    confidence = all_probs[predicted_index]

    # Display prediction
    st.success(f"🪴 **Detected Crop**: `{predicted_class}` with `{confidence*100:.2f}%` confidence.")

    # Build a DataFrame for plotting
    probs_dict = dict(zip(class_names, all_probs.flatten().tolist()))
    df = pd.DataFrame(probs_dict.items(), columns=["Class", "Confidence"])
    df = df.sort_values(by="Confidence", ascending=True)

    st.markdown("### 📊 Prediction Confidence for All Classes")
    # Plot
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.barh(df["Class"], df["Confidence"], color="mediumseagreen")
    ax.set_xlabel("Confidence")
    ax.set_title("📊 Prediction Confidence per Class")
    ax.set_xlim(0, 1)
    plt.tight_layout()

    st.pyplot(fig)