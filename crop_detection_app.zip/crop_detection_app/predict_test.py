from tensorflow.keras.models import load_model
from PIL import Image
import numpy as np
import os

# Load the trained model
model = load_model("crop_model.h5")

# Define class labels — this MUST match your training classes order
class_names = sorted(os.listdir("PlantVillage"))

# Prediction function
def predict_crop(image_path):
    image = Image.open(image_path).resize((64, 64))
    img_array = np.array(image) / 255.0
    img_array = np.expand_dims(img_array, axis=0)
    prediction = model.predict(img_array)
    predicted_class = class_names[np.argmax(prediction)]
    confidence = round(np.max(prediction) * 100, 2)
    return f"{predicted_class} ({confidence}%)"

# Example use
result = predict_crop("leaf_samples/potato_leaf.jpg")  # Change path to your test image
print("Prediction:", result)
